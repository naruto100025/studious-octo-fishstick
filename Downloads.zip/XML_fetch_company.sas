/* preparing company data in xml tags & calling "XML_fetch_address"
, "XML_fetch_phone" & "XML_fetch_company_person" */


libname func_lib "&SAS_CUST_ROOT/data";
options cmplib=(func_lib.go_aml_functions);

proc fcmp outlib=func_lib.go_aml_functions.XML;
  deletefunc XML_fetch_company;
quit;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  /* Declare with $; reference without $ inside the body */
  function XML_fetch_company(company_id$, root_tag_name$, rr_report_id$) $;
    length rc dsid 8 r $32767 wherec $400;

    /* Build the WHERE clause at run time */
    wherec = cats("(where=(relationship_id='",
                  trim(company_id), "' and rr_report_id='", trim(rr_report_id), "'))");

    /* Read the WORK copy made by %goaml_preload (fast); fall back to the database if it isn't there */
    dsid = open(cats("work.sar_company", wherec));
    if dsid = 0 then dsid = open(cats("sar.sar_company", wherec));
    r = '';

    if dsid>0 then do;
      if attrn(dsid, 'NLOBSF')=1 then do;
        rc = fetch(dsid, 'noset');

        /* Outer tag */
        r = cats('<', root_tag_name, '>');

        /* Company fields */
        r = cats(r, XML_tag('name',                    getvarc(dsid,varnum(dsid,'name'))));
        r = cats(r, XML_tag('commercial_name',        getvarc(dsid,varnum(dsid,'commercial_name'))));
        r = cats(r, XML_tag('incorporation_legal_form', getvarc(dsid,varnum(dsid,'incorporation_legal_form'))));
        r = cats(r, XML_tag('incorporation_number',   getvarc(dsid,varnum(dsid,'incorporation_number'))));
        r = cats(r, XML_tag('business',               getvarc(dsid,varnum(dsid,'business'))));

        /* Phones & addresses (company = '0') */
        r = cats(r, XML_fetch_phone(company_id, '0', rr_report_id));
        r = cats(r, XML_fetch_address(company_id, '0', rr_report_id));

        r = cats(r, XML_tag('email',                  getvarc(dsid,varnum(dsid,'email'))));
        r = cats(r, XML_tag('url',                    getvarc(dsid,varnum(dsid,'url'))));
        r = cats(r, XML_tag('incorporation_state',    upcase(getvarc(dsid,varnum(dsid,'incorporation_state')))));
        r = cats(r, XML_tag('incorporation_country_code', upcase(getvarc(dsid,varnum(dsid,'incorporation_country_code')))));

        /* Directors / UBOs */
        r = cats(r, XML_fetch_company_person(company_id, rr_report_id));

        r = cats(r, XML_tag_date('incorporation_date', getvarn(dsid,varnum(dsid,'incorporation_date'))));

        if getvarc(dsid,varnum(dsid,'business_closed'))='True' then
          r = cats(r, XML_tag('business_closed','1'));

        if getvarc(dsid,varnum(dsid,'business_closed')) ne '' then
          r = cats(r, XML_tag_date('date_business_closed', getvarn(dsid,varnum(dsid,'date_business_closed'))));

        r = cats(r, XML_tag('tax_number',              getvarc(dsid,varnum(dsid,'tax_number'))));
        r = cats(r, XML_tag('tax_reg_number',          getvarc(dsid,varnum(dsid,'tax_reg_number'))));

        r = cats(r, '</', root_tag_name, '>');
      end;
      rc = close(dsid);
    end;

    return(strip(r));
  endsub;
run;
quit;
