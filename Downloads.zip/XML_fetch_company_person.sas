/* preparing UOB data in xml tags & calling "XML_fetch_person"*/

libname func_lib "&SAS_CUST_ROOT/data";
options cmplib=func_lib.go_aml_functions;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  deletefunc XML_fetch_company_person;
quit;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  function XML_fetch_company_person(recid$, rr_report_id$) $;
    length rc dsid num_of_rows counter 8 r $32767 wherec $400;

    /* Build WHERE at run time */
    wherec = cats("(where=(company_relationship_id='",
                  trim(recid), "' and rr_report_id='", trim(rr_report_id), "'))");

    r = '';
    /* Read the WORK copy made by %goaml_preload (fast); fall back to the database if it isn't there */
    dsid = open(cats("work.sar_ubo", wherec));
    if dsid = 0 then dsid = open(cats("sar.sar_ubo", wherec));
    if dsid>0 then do;
      num_of_rows = attrn(dsid, 'NLOBSF');
      counter = 0;
      do while (counter < num_of_rows);
        rc = fetch(dsid, 'noset');
        if rc ne 0 then leave;

        r = cats(r, '<director_id>',
                    /* Pass root_tag_name='1' to suppress wrapper inside person */
                    XML_fetch_person(getvarc(dsid,varnum(dsid,'person_relationship_id')), '1', rr_report_id),
                    XML_tag('role', getvarc(dsid,varnum(dsid,'role_id'))),
                 '</director_id>');
        counter+1;
      end;
      rc = close(dsid);
    end;

    return(strip(r));
  endsub;
run;
quit;
