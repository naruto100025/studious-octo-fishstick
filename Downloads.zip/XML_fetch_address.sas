/*Input: person id / company id / goods_service_id 
	& flag (1 for person , 0 for company , 3 for good service*/
/*Desc.: prepating all good service info in tags */

libname func_lib "&SAS_CUST_ROOT/data";
options cmplib=func_lib.go_aml_functions;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  deletefunc XML_fetch_address;
quit;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  /* isperson: '1' person, '0' company, '3' good_service */
  function XML_fetch_address(recid$, isperson$, report_id$) $;
    length dsid rc num_of_rows counter 8 r $32767 wherec $400;

    /* Use parameter names WITHOUT $ inside the body */
    select (strip(isperson));
      when ('1')
        wherec = cats("(where=(person_relationship_id='",
                      trim(recid), "' and rr_report_id='", trim(report_id), "'))");
      when ('0')
        wherec = cats("(where=(company_relationship_id='",
                      trim(recid), "' and rr_report_id='", trim(report_id), "'))");
      when ('3')
        wherec = cats("(where=(goods_service_id='",
                      trim(recid), "'))");
      otherwise
        wherec = '';
    end;

    r = '';
    if wherec ne '' then do;
      /* Persons/companies: read the WORK copy made by %goaml_preload (fast); fall back to the database.
         Goods/services are not filtered by report, so they always read the database. */
      dsid = 0;
      if strip(isperson) ne '3' then dsid = open(cats("work.sar_address", wherec));
      if dsid = 0 then dsid = open(cats("sar.sar_address", wherec));
      if dsid>0 then do;
        num_of_rows = attrn(dsid, 'NLOBSF');
        if num_of_rows>0 then do;
          if strip(isperson) ne '3' then r = cats(r, '<addresses>');
          counter = 0;
          do while (counter < num_of_rows);
            rc = fetch(dsid, 'noset');
            if rc ne 0 then leave;

            r = cats(r, '<address>',
                        XML_tag('address_type', getvarc(dsid,varnum(dsid,'address_type'))),
                        XML_tag('address',      getvarc(dsid,varnum(dsid,'address'))),
                        XML_tag('town',         getvarc(dsid,varnum(dsid,'town'))),
                        XML_tag('city',         getvarc(dsid,varnum(dsid,'city'))),
                        XML_tag('zip',          getvarc(dsid,varnum(dsid,'zip'))),
                        XML_tag('country_code', upcase(getvarc(dsid,varnum(dsid,'country_code_id')))),
                        XML_tag('state',        upcase(getvarc(dsid,varnum(dsid,'state')))),
                     '</address>');
            counter+1;
          end;
          if strip(isperson) ne '3' then r = cats(r, '</addresses>');
        end;
        rc = close(dsid);
      end;
    end;

    return(strip(r));
  endsub;
run;
quit;
