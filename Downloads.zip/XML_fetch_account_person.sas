/* preparing signatory data in xml tags & calling "XML_fetch_person"*/


libname func_lib "&SAS_CUST_ROOT/data";
options cmplib=func_lib.go_aml_functions;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  deletefunc XML_fetch_account_person;
quit;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  function XML_fetch_account_person(recid$, rr_report_id$) $;
    length rc dsid num_of_rows counter 8 r $32767 wherec $400;

    /* Build WHERE at run time */
    wherec = cats("(where=(account_relationship_id='",
                  trim(recid), "' and rr_report_id='", trim(rr_report_id), "'))");

    r = '';
    /* Read the WORK copy made by %goaml_preload (fast); fall back to the database if it isn't there */
    dsid = open(cats("work.sar_signatory", wherec));
    if dsid = 0 then dsid = open(cats("sar.sar_signatory", wherec));
    if dsid>0 then do;
      num_of_rows = attrn(dsid, 'NLOBSF');
      counter = 0;
      do while (counter < num_of_rows);
        rc = fetch(dsid, 'noset');
        if rc ne 0 then leave;

        r = cats(r, "<signatory>");

        if getvarc(dsid,varnum(dsid,'role_id'))='PAH' then
          r = cats(r, XML_tag("is_primary","1"));

        /* Pass a wrapping tag name that matches your schema; here "t_person" */
        r = cats(r,
                 XML_fetch_person(getvarc(dsid,varnum(dsid,'person_relationship_id')), "t_person", rr_report_id),
                 XML_tag("role", getvarc(dsid,varnum(dsid,'role_id'))),
                 "</signatory>");
        counter+1;
      end;
      rc = close(dsid);
    end;

    return(strip(r));
  endsub;
run;
quit;
