
/*libname sar postgres server="sasviya.datascience.intra" port=5431 authdomain="PGdbAuth" schema="fdhdata" database="amluat" DBMAX_TEXT=32767;*/


libname func_lib "&SAS_CUST_ROOT/data";
options cmplib=func_lib.go_aml_functions;

/* (Re)create the function in the same package */
proc fcmp outlib=func_lib.go_aml_functions.XML;
  deletefunc XML_fetch_person;
run;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  function XML_fetch_person(person_id$, root_tag_name$, rr_report_id$) $;
    length rc dsid nobs 8 r $32767 wherec $400 path $200;

    /* WHERE clause for this person */
    wherec = cats("(where=(relationship_id='",
                  trim(person_id),
                  "' and rr_report_id='",
                  trim(rr_report_id),
                  "'))");

    /* Read the WORK copy made by %goaml_preload (fast); fall back to the database if it isn't there */
    dsid = open(cats("work.sar_person", wherec));
    if dsid = 0 then dsid = open(cats("sar.sar_person", wherec));

    if dsid>0 then do;
      /* Use NLOBSF to detect exactly one row without moving the pointer */
      if attrn(dsid, 'NLOBSF')=1 then do;
        rc = fetch(dsid, 'noset');
        r = '';

        /* Optional outer tag */
        if root_tag_name ne '1' then r = cats(r, '<', root_tag_name, '>');

        /* Gender */
        if getvarc(dsid, varnum(dsid, 'gender')) in ('F','M') then
          r = cats(r, XML_tag('gender', getvarc(dsid, varnum(dsid,'gender'))));
        else
          r = cats(r, XML_tag('gender', '-'));

        /* Core person fields */
        r = cats(r, XML_tag('title',        getvarc(dsid, varnum(dsid,'title2'))));
        r = cats(r, XML_tag('first_name',   getvarc(dsid, varnum(dsid,'first_name'))));
        r = cats(r, XML_tag('middle_name',  getvarc(dsid, varnum(dsid,'middle_name'))));
        r = cats(r, XML_tag('prefix',       getvarc(dsid, varnum(dsid,'prefix'))));
        r = cats(r, XML_tag('last_name',    getvarc(dsid, varnum(dsid,'last_name'))));
        r = cats(r, XML_tag_date('birthdate', getvarn(dsid, varnum(dsid,'birthdate'))));
        r = cats(r, XML_tag('birth_place',  getvarc(dsid, varnum(dsid,'birth_place'))));
        r = cats(r, XML_tag('mothers_name', getvarc(dsid, varnum(dsid,'mothers_name'))));
        r = cats(r, XML_tag('alias',        getvarc(dsid, varnum(dsid,'alias'))));
        r = cats(r, XML_tag('ssn',          getvarc(dsid, varnum(dsid,'ssn'))));
        r = cats(r, XML_tag('passport_number', getvarc(dsid, varnum(dsid,'passport_number'))));
        if getvarc(dsid, varnum(dsid,'passport_number')) ne '' and
           getvarc(dsid, varnum(dsid,'passport_country')) ne '' then
          r = cats(r, XML_tag('passport_country', upcase(getvarc(dsid, varnum(dsid,'passport_country')))));
        r = cats(r, XML_tag('id_number',    getvarc(dsid, varnum(dsid,'id_number'))));
        r = cats(r, XML_tag('nationality1', upcase(getvarc(dsid, varnum(dsid,'nationality1')))));
        r = cats(r, XML_tag('nationality2', getvarc(dsid, varnum(dsid,'nationality2'))));
        r = cats(r, XML_tag('nationality3', getvarc(dsid, varnum(dsid,'nationality3'))));
        r = cats(r, XML_tag('residence',    upcase(getvarc(dsid, varnum(dsid,'residence')))));

        /* Phones + addresses (your helper functions) */
        r = cats(r, XML_fetch_phone(person_id, '1', rr_report_id));
        r = cats(r, XML_fetch_address(person_id, '1', rr_report_id));

        /* Contact / employment */
        r = cats(r, XML_tag('email',      getvarc(dsid, varnum(dsid,'email'))));
        r = cats(r, XML_tag('occupation', getvarc(dsid, varnum(dsid,'occupation'))));
        r = cats(r, XML_tag('employer_name', getvarc(dsid, varnum(dsid,'employer_name'))));

        if getvarc(dsid, varnum(dsid,'employer_address')) ne '' or
           getvarc(dsid, varnum(dsid,'employer_city')) ne '' or
           getvarc(dsid, varnum(dsid,'employer_country_code')) ne '' then do;
          r = cats(r, '<employer_address_id>',
                      XML_tag('address_type','-'),
                      XML_tag('address',      coalescec(upcase(getvarc(dsid, varnum(dsid,'employer_address'))), '-')),
                      XML_tag('city',         coalescec(upcase(getvarc(dsid, varnum(dsid,'employer_city'))), '-')),
                      XML_tag('country_code', coalescec(upcase(getvarc(dsid, varnum(dsid,'employer_country_code'))), '-')),
                      XML_tag('state','-'),
                   '</employer_address_id>');
        end;

        if getvarc(dsid, varnum(dsid,'employer_tph_number')) ne '' then do;
          r = cats(r, '<employer_phone_id>',
                      XML_tag('tph_contact_type','-'),
                      XML_tag('tph_communication_type','-'),
                      XML_tag('tph_number', upcase(getvarc(dsid, varnum(dsid,'employer_tph_number')))),
                   '</employer_phone_id>');
        end;

        /* Identifications (call once; you had it twice) */
        r = cats(r, XML_fetch_person_identification(person_id, rr_report_id));

        if getvarc(dsid, varnum(dsid,'deceased')) = 'True' then
          r = cats(r, XML_tag('deceased','1'));
        r = cats(r, XML_tag_date('date_deceased', getvarn(dsid, varnum(dsid,'deceased_date'))));

        r = cats(r, XML_tag('tax_number',      getvarc(dsid, varnum(dsid,'tax_number'))));
        r = cats(r, XML_tag('tax_reg_number',  getvarc(dsid, varnum(dsid,'tax_reg_number'))));
        r = cats(r, XML_tag('source_of_wealth',getvarc(dsid, varnum(dsid,'source_of_wealth'))));

        if root_tag_name ne '1' then r = cats(r, '</', root_tag_name, '>');
      end;
      else r = '';  /* No rows (or >1) – return empty */
      rc = close(dsid);
    end;
    else do;
      /* OPEN failed – return empty to avoid later errors */
      r = '';
    end;

    return(strip(r));
  endsub;
run;
quit;