/*Input: person id / company id / goods_service_id 
	& flag (1 for person , 0 for company , 3 for good service*/
/*Desc.: prepating all good service info in tags */

libname func_lib "&SAS_CUST_ROOT/data";
options cmplib=func_lib.go_aml_functions;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  deletefunc XML_fetch_person_identification;
quit;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  /* NOTE: recid$ and report_id$ are declared as char;
           inside the body, reference them as recid, report_id */
  function XML_fetch_person_identification(recid$, report_id$) $;
    length dsid rc num_of_rows counter 8 r $32767 wherec $400;

    wherec = cats("(where=(person_relationship_id='",
                  trim(recid), "' and rr_report_id='", trim(report_id), "'))");

    r = '';
    /* Read the WORK copy made by %goaml_preload (fast); fall back to the database if it isn't there */
    dsid = open(cats("work.sar_person_identification", wherec));
    if dsid = 0 then dsid = open(cats("sar.sar_person_identification", wherec));
    if dsid > 0 then do;
      num_of_rows = attrn(dsid, 'NLOBSF');
      if num_of_rows > 0 then do;
        counter = 0;
        do while (counter < num_of_rows);
          rc = fetch(dsid, 'noset');
          if rc ne 0 then leave;

          r = cats(r,
                   '<identification>',
                     XML_tag('type',          getvarc(dsid, varnum(dsid,'identification_type'))),
                     XML_tag('number',        getvarc(dsid, varnum(dsid,'identification_number'))),
                     XML_tag_date_ident('issue_date',  getvarn(dsid, varnum(dsid,'identification_issue_date'))),
                     XML_tag_date_ident('expiry_date', getvarn(dsid, varnum(dsid,'identification_expiry_date'))),
                     XML_tag('issued_by',     getvarc(dsid, varnum(dsid,'identification_issued_by'))),
                     XML_tag('issue_country', upcase(getvarc(dsid, varnum(dsid,'issuing_country')))),
                   '</identification>');
          counter + 1;
        end;
      end;
      rc = close(dsid);
    end;

    return(strip(r));
  endsub;
run;
quit;
