/*Input: person id / company id & flag (1 for person , 0 for company)*/
/*Desc.: prepating all phones info in tags */

libname func_lib "&SAS_CUST_ROOT/data";
options cmplib=func_lib.go_aml_functions;

options cmplib=(func_lib.go_aml_functions);

proc fcmp outlib=func_lib.go_aml_functions.XML;
  deletefunc XML_fetch_phone;
quit;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  /* isperson: '1' person, '0' company  (note: no $ in references) */
  function XML_fetch_phone(recid$, isperson$, report_id$) $;
    length dsid rc num_of_rows counter 8 r $32767 wherec $400;

    /* Use the parameter names WITHOUT $ inside the body */
    if strip(isperson)='1' then
      wherec = cats("(where=(person_relationship_id='",
                    trim(recid), "' and rr_report_id='", trim(report_id), "'))");
    else
      wherec = cats("(where=(company_relationship_id='",
                    trim(recid), "' and rr_report_id='", trim(report_id), "'))");

    /* Read the WORK copy made by %goaml_preload (fast); fall back to the database if it isn't there */
    dsid = open(cats("work.sar_phone_number", wherec));
    if dsid = 0 then dsid = open(cats("sar.sar_phone_number", wherec));
    r = '';

    if dsid>0 then do;
      num_of_rows = attrn(dsid, 'NLOBSF');
      if num_of_rows>0 then do;
        r = cats(r, '<phones>');
        counter = 0;
        do while (counter < num_of_rows);
          rc = fetch(dsid, 'noset');
          if rc ne 0 then leave;

          r = cats(r, '<phone>',
                      XML_tag('tph_contact_type',      getvarc(dsid,varnum(dsid,'tph_contact_type_id'))),
                      XML_tag('tph_communication_type',getvarc(dsid,varnum(dsid,'tph_communication_type'))),
                      XML_tag('tph_country_prefix',    getvarc(dsid,varnum(dsid,'tph_country_prefix'))),
                      XML_tag('tph_number',            getvarc(dsid,varnum(dsid,'tph_number'))),
                      XML_tag('tph_extension',         getvarc(dsid,varnum(dsid,'tph_extension'))),
                   '</phone>');
          counter+1;
        end;
        r = cats(r, '</phones>');
      end;
      rc = close(dsid);
    end;

    return(strip(r));
  endsub;
run;
quit;
