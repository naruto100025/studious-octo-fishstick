
/* preparing account data in xml tags & calling "XML_fetch_company"
& "XML_fetch_account_person" */
libname func_lib "&SAS_CUST_ROOT/data";
options cmplib=(func_lib.go_aml_functions);

proc fcmp outlib=func_lib.go_aml_functions.XML;
  deletefunc XML_fetch_account;
quit;

proc fcmp outlib=func_lib.go_aml_functions.XML;
  /* account_id$, root_tag_name$, rr_report_id$ are declared char;
     inside the body, use account_id, root_tag_name, rr_report_id */
  function XML_fetch_account(account_id$, root_tag_name$, rr_report_id$,balance_amount$,date_transaction$) $;
    length rc dsid 8 r $32767 wherec $400;

    /* Build WHERE at run time (no macros) */
    wherec = cats("(where=(relationship_id='",
                  trim(account_id), "' and rr_report_id='", trim(rr_report_id), "'))");

    /* Read the WORK copy made by %goaml_preload (fast); fall back to the database if it isn't there */
    dsid = open(cats("work.sar_account", wherec));
    if dsid = 0 then dsid = open(cats("sar.sar_account", wherec));
    r = '';

    if dsid>0 then do;
      if attrn(dsid, 'NLOBSF')=1 then do;
        rc = fetch(dsid, 'noset');

        r = cats("<", root_tag_name, ">");
        r = cats(r, XML_tag("institution_name", getvarc(dsid,varnum(dsid,'institution_name'))));

        if getvarc(dsid,varnum(dsid,'swift')) ne '' then
          r = cats(r, XML_tag("swift", getvarc(dsid,varnum(dsid,'swift'))));
        else
          r = cats(r, XML_tag("institution_code", getvarc(dsid,varnum(dsid,'institution_code'))));

        if getvarc(dsid,varnum(dsid,'non_bank_institution'))='True' then
          r = cats(r, XML_tag("non_bank_institution","true"));
        else if getvarc(dsid,varnum(dsid,'non_bank_institution'))='False' then
          r = cats(r, XML_tag("non_bank_institution","false"));

        r = cats(r, XML_tag("branch",                 getvarc(dsid,varnum(dsid,'branch'))));
        r = cats(r, XML_tag("account",                getvarc(dsid,varnum(dsid,'account'))));
        r = cats(r, XML_tag("currency_code",          getvarc(dsid,varnum(dsid,'currency_code'))));
        r = cats(r, XML_tag("account_name",           getvarc(dsid,varnum(dsid,'account_name'))));
        r = cats(r, XML_tag("iban",                   getvarc(dsid,varnum(dsid,'iban'))));
        r = cats(r, XML_tag("client_number",          getvarc(dsid,varnum(dsid,'client_number'))));
        r = cats(r, XML_tag("personal_account_type",  getvarc(dsid,varnum(dsid,'personal_account_type'))));

        /* Optional nested company */
        if getvarc(dsid,varnum(dsid,'company_id')) ne '' then
          r = cats(r, XML_fetch_company(getvarc(dsid,varnum(dsid,'company_id')), "t_entity", rr_report_id));

        /* Signatories for this account */
        r = cats(r, XML_fetch_account_person(account_id, rr_report_id));

        r = cats(r, XML_tag_date("opened", getvarn(dsid,varnum(dsid,'opened'))));
        r = cats(r, XML_tag_date("closed", getvarn(dsid,varnum(dsid,'closed'))));
%let debug=varnum(dsid,'balance');
			%put &=debug;

			if "&report_code_id." eq "STR" 
			
			 or "&report_code_id."  eq "AIFT" 
              or "&report_code_id."  eq "HRC"
      
                 or "&report_code_id."  eq "ITR" 
                   or "&report_code_id."  eq "PSTR" 
                     or "&report_code_id."  eq "ECDDT" 
        
              
              then do;
 if getvarc(dsid,varnum(dsid,'myclient')) ne "False" then do;
				r= cats(r, XML_tag("balance", balance_amount));
				r= cats(r, XML_tag_date("date_balance", date_transaction));
			end;
end;
			else do;
			
        if getvarn(dsid,varnum(dsid,'balance')) ne . then do;
          r = cats(r, XML_tag("balance", getvarn(dsid,varnum(dsid,'balance'))));
          r = cats(r, XML_tag_date("date_balance", getvarn(dsid,varnum(dsid,'date_balance'))));
        end;
end;

        r = cats(r, XML_tag("status_code",  getvarc(dsid,varnum(dsid,'status_code'))));
        r = cats(r, XML_tag("beneficiary",  getvarc(dsid,varnum(dsid,'beneficiary'))));

        r = cats(r, "</", root_tag_name, ">");
      end;
      rc = close(dsid);
    end;

    return(strip(r));
  endsub;
run;
quit;
